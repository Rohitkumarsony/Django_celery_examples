import os
from time import sleep
from datetime import timedelta
from celery import Celery
from celery.schedules import crontab

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'proj.settings')

app = Celery('proj')


app.config_from_object('django.conf:settings', namespace='CELERY')

app.autodiscover_tasks()

#it is used to change taskname in database
# @app.task(name="additional_tasks")
@app.task
def add(x,y):
    sleep(20)
    return x+y


# #second method for beat scheduling
# app.conf.beat_schedule={
#     'every-10-seconds':{
#         'task':'app.tasks.clear_session_cache',
#         'schedule':10,
#         'args':('11111',)
#     }
# }

#third  method for beat scheduling using time delta
# app.conf.beat_schedule={
#     'every-10-seconds':{
#         'task':'app.tasks.clear_session_cache',
#         'schedule':timedelta(seconds=10),
#         'args':('11111',)
#     }
# }

#$$$$use crontab for advance label scheduling day months year

app.conf.beat_schedule={
    'every-1-minutes':{
        'task':'app.tasks.clear_session_cache',
        'schedule':crontab(minute='*/1'),
        'args':('11111',)
    }
}

